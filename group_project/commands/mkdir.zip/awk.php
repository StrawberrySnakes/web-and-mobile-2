<?php
$pageTitle = "awk - Commands";
$path = "../";
include($path . "inc/navbar.php");

?>
    <main id="commands">
        <h1>awk</h1>
        <p>Awk is used for maipulating data based on text patterns. It outputs all lines from the file that match the string specified by the selection_criteria</p>
        <p class=code>~$ awk 'selection_criteria {action}' input-file > output-file</P>
        <a href="grep.php"><button>Global Regular Expression Print</button></a>

    </main>

<?php

    include($path . "inc/footer.php");

?>