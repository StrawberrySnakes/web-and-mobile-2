<!-- Footer html elements -->
</div> 
	<footer>Dan's Pizza Shoppe &reg;</footer>
</body>
</html>