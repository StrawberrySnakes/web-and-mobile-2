function drawTriangle(triangleSize) {

   // Your solution goes here
   
}