        <footer>
            <script src="assets/scripts/script.js"></script>
            &copy; Dessa Shapiro <?php echo $year?>
        </footer>

    </body>


</html>